//
//  PersonalInfo.swift
//  HelloWorld
//
//  Created by Jolijn Friederichs on 19-11-17.
//  Copyright © 2017 Any. All rights reserved.
//

import Foundation

struct PersonalInfo {
    
    var name = "Jolijn"
    
}
